#ifndef TES_H
#define TES_H


class tes
{
    public:
        tes();
        virtual ~tes();

    protected:

    private:
};

#endif // TES_H
