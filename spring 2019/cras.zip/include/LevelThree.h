#ifndef LEVELTHREE_H
#define LEVELTHREE_H


class LevelThree
{
    public:
        LevelThree();
        virtual ~LevelThree();

    protected:

    private:
};

#endif // LEVELTHREE_H
