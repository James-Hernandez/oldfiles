#include "tes.h"

tes::tes()
{
    //ctor
}

tes::~tes()
{
    //dtor
}
