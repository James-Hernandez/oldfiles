#include "CollisionChecker.h"

CollisionChecker::CollisionChecker()
{
    //ctor
    //coinSound->initSounds();
}

CollisionChecker::~CollisionChecker()
{
    //dtor
}
