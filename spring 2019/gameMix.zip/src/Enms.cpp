#include "Enms.h"

Enms::Enms()
{
    //ctor
    xPos = 0.0;
    yPos = 0.0;
    zPos = -3.;//-0.5

    xSize = ySize = 1.0;

    rotateX = rotateY = rotateZ = 0.0;
    xMove = 0.01;




}

Enms::~Enms()
{
    //dtor
}
void Enms::EnmyInit()
{
   frames = 1;
    xMin = yMin = 0.0;
    xMax = 0.111111/(float)frames;
    yMax = 0.25;
    yPos = -0.5;

}

void Enms::drawEnemy()
{
        glPushMatrix();

    glTranslated(xPos,yPos,zPos);
    glRotated(rotateX,1.0,0.0,0.0);
    glRotated(rotateY,0.0,1.0,0.0);
    glRotated(rotateZ,0.0,0.0,1.0);

    glBindTexture(GL_TEXTURE_2D,enemyTex);
    glScaled(xSize, ySize,1.0);


glBegin(GL_QUADS);

    glTexCoord2f(xMin,yMax);
    glVertex3f(1.0,0.0,0.0);

    glTexCoord2f(xMax,yMax);
    glVertex3f(0.0,0.0,0.0);

    glTexCoord2f(xMax,yMin);
    glVertex3f(0.0,1.0,0.0);

    glTexCoord2f(xMin,yMin);
    glVertex3f(1.0,1.0,0.0);

glEnd();
glPopMatrix();
}

void Enms::placeEnemy(float x, float y, float z)
{
    xPos = x;
    yPos = y;
    zPos = z;
}

void Enms::actions()
{
    switch(action)
    {
        case 0:
if(TE->getTicks() > 80){

                xMin += 0.111111/(float)frames;
                xMax += 0.111111/(float)frames;

                yMin = 0.75;
                yMax = 1.0;

                if(xMin >= 1){
                    xMax = 0.111111;
                    xMin = 0.0/(float)frames;
                }

                TE->reset();
            }

            break;

        case 1:

            if(TE->getTicks() > 80){

                xMin += 0.111111/(float)frames;
                xMax += 0.111111/(float)frames;

                yMin = 0.25;
                yMax = 0.5;

                if(xMin >= 1){
                    xMax = 0.111111;
                    xMin = 0.0/(float)frames;
                }

                TE->reset();
            }

            break;

        case 2:

            break;

    }
}
