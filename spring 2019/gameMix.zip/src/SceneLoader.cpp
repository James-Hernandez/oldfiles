#include "SceneLoader.h"
#include<LevelOne.h>

SceneLoader::SceneLoader(GLScene* scene)
{
    currScene = "LevelOne";
    sceneMap[currScene] = scene;
}

SceneLoader::SceneLoader(string name, GLScene* scene)
{
    currScene = name;
    sceneMap[currScene] = scene;
}

SceneLoader::~SceneLoader()
{
    //dtor
}

void SceneLoader::loadScene(string name, GLScene* scene)
{
    string oldScene = currScene;

    if(currScene == "LevelOne"){
        sceneMap[name] = scene;
        currScene = name;
        sceneMap[name]->initGL();
    }

    //deleteScene(oldScene);
}

void SceneLoader::deleteScene(string oldScene)
{
   if(sceneMap.erase(oldScene) == 1){
        cout << "Erased " << oldScene << endl;
    }
    // not sure if I want this here. we'll see later.
}

GLScene* SceneLoader::getCurrScene()
{
   return sceneMap[currScene];
}
