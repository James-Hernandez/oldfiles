#include "LevelOne.h"
#include <GLLight.h>
//#include<Inputs.h>
#include<Model.h>
#include<Parallax.h>
//#include<Player.h>
#include<Objects.h>
#include<Enms.h>
#include<windows.h>

static Parallax* plx = new Parallax();
static Inputs *KbMs = new Inputs();
///Model *Mdl = new Model();
static Player *ply = new Player();
static Objects Obj[10];///because of multiple objects these are the bit coins
static Objects coin[6];///these are the litecoins
static Enms Enemy[10];///not using yet!
static TextureLoader *objTex = new TextureLoader();
static TextureLoader *ETex = new TextureLoader();
static TextureLoader *coinTex = new TextureLoader();
LevelOne::LevelOne()
{
    //ctor
    screenHeight = GetSystemMetrics(SM_CYSCREEN);
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
}

LevelOne::~LevelOne()
{
    //dtor
}
GLint LevelOne::initGL()
{
    glShadeModel(GL_SMOOTH);//for good transition in animations
    glClearColor(0.5f,1.0f,0.0f,0.0f);//set background color
    glClearDepth(1.0f);//decide what is at front and behind
    glEnable(GL_DEPTH_TEST);//for the depth calculations
    //glEnable(GL_COLOR_MATERIAL);
    GLLight Light(GL_LIGHT0);//create light instance



    /*int GLScene::winMsg(HWND hWnd, UNIT uMsg, WPARAM wParam, LPARAM lParam)
    {

    }
    */
    Light.setLight(GL_LIGHT0);
    //Mdl->modelInit("images/teapot.png");
    plx->parallaxInit("images/level 1.png");
    ply->playerInit("images/CarSpriteSheet.png");
    objTex->loadTexture("images/coin.png");
    coinTex->loadTexture("images/Ecoin.png");
    ETex->loadTexture("images/enemy.png");
/*
    for(int i = 0; i < 10; i++)
    {

   // Obj[i].xSize = Obj[i].ySize = (rand()% 5)/10.0;

    //Obj[i].placeObjects(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);//((rand()% 10)-10)/10.0,-0.5);

    //Obj[i].ySize = (rand()% 10)/10.0;
   // Obj[i].objectsInit();

    Enemy[i].enemyTex = ETex->tex;
    Enemy[i].EnmyInit();
    Enemy[i].xPos = (float)(rand())/float (RAND_MAX) *5 - 2.5;
   // Enemy[i].yPos = -0.5;
   // Enemy[i].placeEnemy(Enemy[i].xPos,Enemy[i].yPos, -0.3);
    Enemy[i].ySize = Enemy[i].xSize = (float) (rand()%12)/50.0;

    }

*/
    for(int z = 0; z < 6; z++){
        coin[z].xSize = coin[z].ySize = 0.1;
        coin[z].placeObjects(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);
        coin[z].objectsInit();
    }


    for(int j = 0; j < 10; j++){
        Obj[j].xSize = Obj[j].ySize = 0.1;//(rand()% 5)/10.0;
//cout << Obj[j].xSize << " " << Obj[j].ySize << endl;
    Obj[j].placeObjects(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);//((rand()% 10)-10)/10.0,-0.5);

    //Obj[i].ySize = (rand()% 10)/10.0;
    Obj[j].objectsInit();

    }


    return true;
}

GLint LevelOne::drawGLScene()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
glLoadIdentity();

///////////////////////////////////////////////////////
glPushMatrix();
plx->drawSquare(screenWidth,screenHeight);
glPopMatrix();
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
glPushMatrix();

    objTex->binder();

    for(int i =0; i < 10; i++){

       Obj[i].drawObjects();


    }


glPopMatrix();
///////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
glPushMatrix();
coinTex->binder();
for(int z =0; z < 6; z++){

       coin[z].drawObjects();


    }
glPopMatrix();
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
glPushMatrix();

    //objTex->binder();
    //Obj[0].drawObjects();
    /*
    for(int i = 0; i < 10; i++){
           // Obj[i].xSize = Obj[i].ySize = (rand()% 5)/10.0;
           //Obj[i].placeObjects(((rand()% 20)-10)/10.0,((rand()% 10)-10)/10.0,-0.5);
       Enemy[i].drawEnemy();
      // Enemy[i].yPos = -0.5;
       //Obj[i].drawObjects();
        Enemy[i].action = 0;
      Enemy[i].actions();
      if(Enemy[i].xPos< -2.0){
        Enemy[i].xMove = 0.01;
        Enemy[i].action = 0;
      }
      else if(Enemy[i].xPos >2.0){
        Enemy[i].xMove = -0.01;
        Enemy[i].action = 1;
      }
      Enemy[i].xPos += Enemy[i].xMove;

    }
    */
//obj->moveObjects();
glPopMatrix();
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
glPushMatrix();
    glTranslated(ply->xPos,ply->yPos,ply->zPos);
    glScaled(0.15,0.15,0.15);
    ply->drawPlayer();
    ply->playerActions();
glPopMatrix();
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
//ply->playerActions("left");
//ply->playerActions("right");
///plx->scroll("up",0.01);

}/*
void LevelOne::playerMovements(Player* ply)
{
 switch(wParam){
case VK_LEFT:
    ply->actionTrigger = "Left";
    break;
case VK_RIGHT:
    ply->actionTrigger = "Right";
    break;
case VK_UP:
    ply->actionTrigger = "Up";
    break;
case VK_DOWN:
    ply->actionTrigger = "Down";
    break;
}
}
*/
int LevelOne::winMsg(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(wParam){
case VK_LEFT:
    ply->actionTrigger = "Left";
    break;
case VK_RIGHT:
    ply->actionTrigger = "Right";
    break;
case VK_UP:
    ply->actionTrigger = "Up";
    break;
case VK_DOWN:
    ply->actionTrigger = "Down";
    break;
}


   switch(uMsg){
        case WM_KEYDOWN:

            KbMs ->wParam = wParam;
			KbMs ->keyPressed(Mdl);
			KbMs ->keyEnv(plx,0.005);
			KbMs ->playerAction(ply);
            if(wParam == int('p') || wParam == int('P')){
                // go to first level.
                /*
                if(mouseX > -4.9767 && mouseX < 0.668879 && mouseY > 0.68 && mouseY < 1.4114){
                    GLScene* scene = new GLScene();
                    loader->loadScene("level1", scene);
                }
                */
            }
            //ply ->actionTrigger = "Down";
	    break;

        case WM_KEYUP:								// Has A Key Been Released?
		{
			//ply ->actionTrigger = "Up";								// Jump Back


		}break;



		case WM_LBUTTONDOWN:
        {
            //ply ->actionTrigger = "Left";
            //KbMs->wParam = wParam;
            //KbMs->mouseEventDown(Mdl, LOWORD(lParam),HIWORD(lParam));
            GLdouble modelMat[16];
            GLdouble projMat[16];
            GLint viewport[4];
            glGetDoublev(GL_MODELVIEW_MATRIX, modelMat);
            glGetDoublev(GL_PROJECTION_MATRIX, projMat);
            glGetIntegerv(GL_VIEWPORT, viewport);
            //cout << LOWORD(lParam) << ", " << HIWORD(lParam) << endl;
            GLScene::convertMouseCoord((float)LOWORD(lParam), (float) viewport[3] - (GLfloat)HIWORD(lParam) - 1, modelMat, projMat, viewport);
            if(mouseX > -4.9767 && mouseX < 0.668879 && mouseY > 0.68 && mouseY < 1.4114){
                //GLScene* scene = new GLScene();
                //loader->loadScene("level1", scene);
            }
            else if(mouseX > -4.96443 && mouseX < -1.96982 && mouseY < -0.902066 && mouseY > -1.68754){
                DestroyWindow(hWnd);
            }

        break;								// Jump Back
        }
    }
}

GLvoid LevelOne::resizeGLScene(GLsizei width, GLsizei height)
{

}

