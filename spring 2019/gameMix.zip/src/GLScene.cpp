#include "GLScene.h"
#include <GLLight.h>

#include<math.h>
#include<algorithm>


Objects Obj[10];///because of multiple objects
Enms Enemy[10];


GLScene::GLScene()
{
    //ctor
    screenHeight = GetSystemMetrics(SM_CYSCREEN);
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
}

GLScene::~GLScene()
{
    //dtor
}
GLint GLScene::initGL()
{
    glShadeModel(GL_SMOOTH);//for good transition in animations
    glClearColor(0.5f,1.0f,0.0f,0.0f);//set background color
    glClearDepth(1.0f);//decide what is at front and behind
    glEnable(GL_DEPTH_TEST);//for the depth calculations
    //glEnable(GL_COLOR_MATERIAL);
    GLLight Light(GL_LIGHT0);//create light instance



    /*int GLScene::winMsg(HWND hWnd, UNIT uMsg, WPARAM wParam, LPARAM lParam)
    {

    }
    */
    Light.setLight(GL_LIGHT0);
    Mdl->modelInit("images/teapot.png");
    plx->parallaxInit("images/level 1.png");
    ply->playerInit("images/CarSpriteSheet.png");
    objTex->loadTexture("images/asteroid.png");
    ETex->loadTexture("images/enemy.png");
/*
    for(int i = 0; i < 10; i++)
    {

   // Obj[i].xSize = Obj[i].ySize = (rand()% 5)/10.0;

    //Obj[i].placeObjects(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);//((rand()% 10)-10)/10.0,-0.5);

    //Obj[i].ySize = (rand()% 10)/10.0;
   // Obj[i].objectsInit();

    Enemy[i].enemyTex = ETex->tex;
    Enemy[i].EnmyInit();
    Enemy[i].xPos = (float)(rand())/float (RAND_MAX) *5 - 2.5;
   // Enemy[i].yPos = -0.5;
   // Enemy[i].placeEnemy(Enemy[i].xPos,Enemy[i].yPos, -0.3);
    Enemy[i].ySize = Enemy[i].xSize = (float) (rand()%12)/50.0;

    }
*/

    return true;
}

GLint GLScene::drawGLScene()
{
glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
glLoadIdentity();

/*
glPushMatrix();
Mdl->drawModel();
glPopMatrix();
*/
/*
glPushMatrix();
plx->drawSquare(screenWidth,screenHeight);
glPopMatrix();

glPushMatrix();

    //objTex->binder();
    //Obj[0].drawObjects();
    for(int i = 0; i < 10; i++){
           // Obj[i].xSize = Obj[i].ySize = (rand()% 5)/10.0;
           //Obj[i].placeObjects(((rand()% 20)-10)/10.0,((rand()% 10)-10)/10.0,-0.5);
       Enemy[i].drawEnemy();
      // Enemy[i].yPos = -0.5;
       //Obj[i].drawObjects();
        Enemy[i].action = 0;
      Enemy[i].actions();
      if(Enemy[i].xPos< -2.0){
        Enemy[i].xMove = 0.01;
        Enemy[i].action = 0;
      }
      else if(Enemy[i].xPos >2.0){
        Enemy[i].xMove = -0.01;
        Enemy[i].action = 1;
      }
      Enemy[i].xPos += Enemy[i].xMove;

    }
//obj->moveObjects();
glPopMatrix();

glPushMatrix();
    glTranslated(ply->xPos,ply->yPos,ply->zPos);
    glScaled(0.15,0.15,0.15);
    ply->drawPlayer();
    ply->playerActions();
glPopMatrix();
//ply->playerActions("left");
//ply->playerActions("right");
///plx->scroll("up",0.01);
*/

}
void GLScene::convertMouseCoord(float x, float y, GLdouble* modelMat, GLdouble* projMat, GLint* viewport)
{
    GLfloat nx, ny, nz;
    nx = x;
    ny = y;
    glReadPixels(nx, (float)ny, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &nz);
    gluUnProject(nx, ny, nz, modelMat, projMat, viewport, &mouseX, &mouseY, &mouseZ);
}

GLvoid GLScene::resizeGLScene(GLsizei width, GLsizei height)
{
    GLfloat aspectRatio = (GLfloat)width/(GLfloat)height;
    glViewport(0,0,width,height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0,aspectRatio,0.1,100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    screenHeight = GetSystemMetrics(SM_CYSCREEN);
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
}


int GLScene::winMsg(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
    {

        switch(uMsg)
        {
        case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			KbMs ->wParam = wParam;
			KbMs ->keyPressed(Mdl);
			KbMs ->keyEnv(plx,0.005);
			KbMs ->playerAction(ply);
		}break;

        case WM_KEYUP:								// Has A Key Been Released?
		{
			ply ->actionTrigger = "Stand";								// Jump Back


		}break;

		case WM_LBUTTONDOWN:
        {
            KbMs->wParam = wParam;
            KbMs->mouseEventDown(Mdl,LOWORD(lParam),HIWORD(lParam));
        break;								// Jump Back
        }

   		case WM_RBUTTONDOWN:
        {
            KbMs->wParam = wParam;
            KbMs->mouseEventDown(Mdl,LOWORD(lParam),HIWORD(lParam));
        break;								// Jump Back
        }

          case WM_MBUTTONDOWN:
        {
            KbMs->wParam = wParam;
            KbMs->mouseEventDown(Mdl,LOWORD(lParam),HIWORD(lParam));
        break;								// Jump Back
        }

        case WM_LBUTTONUP:
        case WM_RBUTTONUP:
        case WM_MBUTTONUP:
        {
            KbMs->mouseEventUp();
        break;								// Jump Back
        }

        case WM_MOUSEMOVE:
        {
             KbMs->mouseEventMove(Mdl,LOWORD(lParam),HIWORD(lParam));
        break;								// Jump Back
        }

        case WM_MOUSEWHEEL:
        {
            KbMs->mouseEventWheel(Mdl,(double)GET_WHEEL_DELTA_WPARAM(wParam));
        break;								// Jump Back
        }
}

}


