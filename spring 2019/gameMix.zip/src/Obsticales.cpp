#include "Obsticales.h"

Obsticales::Obsticales()
{
    //ctor
}

Obsticales::~Obsticales()
{
    //dtor
}
