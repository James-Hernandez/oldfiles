#ifndef SCENELOADER_H
#define SCENELOADER_H
#include<unordered_map>
#include<string>
#include <GLScene.h>
#include<LevelOne.h>
#include<SceneLoader.h>

class GLScene;

class SceneLoader
{
    public:
        SceneLoader(GLScene*);
        SceneLoader(string,GLScene*);
        virtual ~SceneLoader();
        void loadScene(string, GLScene*);

        void deleteScene(string);

        GLScene* getCurrScene();

        unordered_map<string,GLScene*> sceneMap;
        string currScene;
    protected:

    private:
};

#endif // SCENELOADER_H
