#ifndef OBSTICALES_H
#define OBSTICALES_H
#include<Player.h>
#include<TextureLoader.h>

using namespace std;

class Obsticales
{
    public:
        Obsticales();
        virtual ~Obsticales();
     vec verticies [4];
    protected:

    private:
};

#endif // OBSTICALES_H
