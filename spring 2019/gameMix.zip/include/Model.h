#ifndef MODEL_H
#define MODEL_H

#include<windows.h>
#include<GL/glut.h>
#include<TextureLoader.h>
class Model
{
    public:
        Model();
        virtual ~Model();

        void drawModel();
        void modelInit(char*);

        double RotateX;
        double RotateY;
        double RotateZ;

        double zoom;
        double xPos;
        double yPos;

TextureLoader *tex = new TextureLoader();
    protected:

    private:
};

#endif // MODEL_H
