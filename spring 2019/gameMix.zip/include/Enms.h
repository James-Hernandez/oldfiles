#ifndef ENMS_H
#define ENMS_H

#include<GL/gl.h>
#include<Timer.h>

class Enms
{
    public:
        Enms();
        virtual ~Enms();

        void drawEnemy();
        void placeEnemy(float,float,float);
        void actions();
        void EnmyInit();


        bool isEnenmyLive = true;
        GLuint enemyTex;
        float xPos,yPos,zPos;
        float xSize, ySize,zSize;

        float rotateX, rotateY, rotateZ;
        int frames;
        int action = 0;
        float xMove;

        Timer *TE = new Timer();
        float xMin,yMin,xMax,yMax;

    protected:

    private:
};

#endif // ENMS_H
