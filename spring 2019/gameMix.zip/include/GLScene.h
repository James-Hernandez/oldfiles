#ifndef GLSCENE_H
#define GLSCENE_H
#include <windows.h>
#include <GL/glut.h>
#include<Inputs.h>
#include<Model.h>
#include<Parallax.h>
#include<Player.h>
#include<Objects.h>
#include<Enms.h>

class GLScene
{
    public:
        GLScene();                             //constructor
        virtual ~GLScene();                    //De-constructor
        virtual GLint initGL();
        virtual GLint drawGLScene();
       GLvoid resizeGLScene(GLsizei,GLsizei);

       virtual int winMsg(HWND,UINT,WPARAM,LPARAM);			// Handle For This Window
         void convertMouseCoord(float, float, GLdouble*, GLdouble*, GLint*);
        double mouseX, mouseY, mouseZ;
        float screenWidth,screenHeight;

    Inputs *KbMs = new Inputs();
    Model *Mdl = new Model();
    Parallax *plx = new Parallax();
    Player *ply = new Player();
    TextureLoader *objTex = new TextureLoader();
    TextureLoader *ETex = new TextureLoader();
    protected:

    private:
};

#endif // GLSCENE_H
