#ifndef PLAYER_H
#define PLAYER_H

#include<GL/gl.h>
#include<TextureLoader.h>
#include <Timer.h>

typedef struct {

    float x;
    float y;
    float z;
}vec;


class Player
{
    public:
        Player();
        virtual ~Player();

        void drawPlayer();
        void playerInit(char *);
        void playerActions();
        string actionTrigger;
        vec verticies[4];

float xMin,yMin,xMax,yMax;
TextureLoader * T = new TextureLoader();
Timer *Time = new Timer();
float xPos, yPos, zPos;

    protected:

    private:
};

#endif // PLAYER_H
