# Coin-Crash

<h1>Step 1</h1>
<img src="https://i.imgur.com/KoUrWBk.png">

<h1>Step 2</h1>
<img src="https://i.imgur.com/hA1QyKw.png">

<h1>Step 3</h1>
<img src="https://i.imgur.com/wf7y14k.png">

<h1>Step 4</h1>
Go to search directories and adjust path's properly. 

