#ifndef LIGHTCOIN_H
#define LIGHTCOIN_H
#include<GL/gl.h>
#include <TextureLoader.h>
#include <Timer.h>


typedef struct {
    float x, y, z;
}vec2;


class LightCoin
{
    public:
        LightCoin();
        virtual ~LightCoin();

        void coinInit();
        void drawCoin();
        void placeCoins(float, float, float);
        void assignTex(char*);

        bool isAlive = true;
        GLuint coinTex1;

        float xPos, yPos, zPos;
        float xSize, ySize;
        float rotateX, rotateY, rotateZ;

        float xMin, yMin;
        float xMax, yMax;
        vec2 verticies[4];

    protected:

    private:
};

#endif // LIGHTCOIN_H
