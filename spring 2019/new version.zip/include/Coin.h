#ifndef COIN_H
#define COIN_H

#include<GL/gl.h>
#include <TextureLoader.h>
#include <Timer.h>

typedef struct {
    float x, y, z;
}vec3;

class Coin
{
    public:
        Coin();
        virtual ~Coin();

        void coinInit();
        void drawCoin();
        void placeCoins(float, float, float);
        void assignTex(char*);

        bool isAlive = true;
        GLuint coinTex;

        float xPos, yPos, zPos;
        float xSize, ySize;
        float rotateX, rotateY, rotateZ;

        float xMin, yMin;
        float xMax, yMax;
        vec3 verticies[4];
    protected:

    private:
};

#endif // COIN_H
