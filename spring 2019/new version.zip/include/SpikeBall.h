#ifndef SPIKEBALL_H
#define SPIKEBALL_H

#include<GL/gl.h>
#include <TextureLoader.h>
#include <Timer.h>

typedef struct {
    float x, y, z;
}vec4;

class SpikeBall
{
    public:
        SpikeBall();
        virtual ~SpikeBall();
        void coinInit();
        void drawCoin(int);
        void placeCoins(float, float, float);
        void assignTex(char*);

        bool isAlive = true;
        GLuint coinTex3;

        float xPos, yPos, zPos;
        float xSize, ySize;
        float rotateX, rotateY, rotateZ;

        float xMin, yMin;
        float xMax, yMax;
        vec4 verticies[4];

    protected:

    private:
};

#endif // SPIKEBALL_H
