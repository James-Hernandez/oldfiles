#include "SpikeBall.h"

Timer *Time5 = new Timer();
SpikeBall::SpikeBall()
{
    //ctor
    xPos = 0;
    yPos = 0;
    zPos = -0.5;

    xSize = 0.03;
    ySize = 0.03;

    rotateX = 0.0;
    rotateY = 0.0;
    rotateZ = 0.0;

    //moveObj = false;

    verticies[0].x = 0.0; verticies[0].y = 0.0; verticies[0].z = -1.0;
    verticies[1].x = 1.0; verticies[1].y = 0.0; verticies[1].z = -1.0;
    verticies[2].x = 1.0; verticies[2].y = 1.0; verticies[2].z = -1.0;
    verticies[3].x = 0.0; verticies[3].y = 1.0; verticies[3].z = -1.0;

    xMin = yMin = 0.0;
    xMax = yMax = 1.0;
}

SpikeBall::~SpikeBall()
{
    //dtor
}
void SpikeBall::coinInit()
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    //T1->loadTexture(fileName);
    Time5->start();
    xMin = 0.0;
    xMax = 1.0;
    yMin = 0.0;
    yMax = 1.0;
}

void SpikeBall::drawCoin(int action)
{
/*
    switch(action){
case 0:
    yPos -= 0.0008;
    if(yPos < -.9){
        xPos = -0.95;
        yPos = ((rand()% 20)-10)/10.0;
    }
    action = 1;
    //break;
case 1:
    xPos += 0.0008;
    if(xPos > .9){
        yPos = -0.6;
                yPos = ((rand()% 20)-10)/10.0;
    }
    action = 0;
    break;


    }
    */

     yPos -= 0.0008;   // call coin movements right here
        if(yPos < -.9){
        yPos = 0.6;
        xPos = ((rand()% 20)-10)/10.0;
        }

    //T1->binder();
    glPushMatrix();
        glTranslated(xPos, yPos, zPos);
        glRotated(rotateX, 1.0, 0.0, 0.0);
        glRotated(rotateY, 0.0, 1.0, 0.0);
        glRotated(rotateZ, 0.0, 0.0, 1.0);
        glScaled(xSize, ySize, 1.0);
        glBegin(GL_QUADS);
            glTexCoord2d(xMin, yMax);
            glVertex3f(verticies[0].x, verticies[0].y, verticies[0].z);

            glTexCoord2d(xMax, yMax);
            glVertex3f(verticies[1].x, verticies[1].y, verticies[1].z);

            glTexCoord2d(xMax, yMin);
            glVertex3f(verticies[2].x, verticies[2].y, verticies[2].z);

            glTexCoord2d(xMin, yMin);
            glVertex3f(verticies[3].x, verticies[3].y, verticies[3].z);
        glEnd();
    glPopMatrix();
}

void SpikeBall::placeCoins(float x, float y, float z)
{
    xPos = x;
    yPos = y;
    zPos = z;
}

void SpikeBall::assignTex(char*)
{

}
