#include "LevelOne.h"
#include <GLLight.h>
#include<Model.h>
#include<Parallax.h>
//#include<Objects.h>
//#include<Enms.h>
#include<windows.h>

static Parallax* plx = new Parallax();
static Inputs *KbMs = new Inputs();
///Model *Mdl = new Model();
static Player *ply = new Player();


static Coin bitcoin[10];//fot bit coin
static LightCoin lightcoin[6];
static SpikeBall spikeball[4];

static TextureLoader *spikeTex = new TextureLoader();
static TextureLoader *lightcoinTex = new TextureLoader();
static TextureLoader *bitcoinTex = new TextureLoader();
static TextureLoader *ETex = new TextureLoader();
static TextureLoader *coinTex = new TextureLoader();//for bitcoin
LevelOne::LevelOne(SceneLoader* loader)
{
    //ctor
    screenHeight = GetSystemMetrics(SM_CYSCREEN);
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
    this->loader = loader;
}

LevelOne::~LevelOne()
{
    //dtor
}
GLint LevelOne::initGL()
{
    glShadeModel(GL_SMOOTH);//for good transition in animations
    glClearColor(0.5f,1.0f,0.0f,0.0f);//set background color
    glClearDepth(1.0f);//decide what is at front and behind
    glEnable(GL_DEPTH_TEST);//for the depth calculations
    //glEnable(GL_COLOR_MATERIAL);
    GLLight Light(GL_LIGHT0);//create light instance

    Light.setLight(GL_LIGHT0);
    //Mdl->modelInit("images/teapot.png");
    plx->parallaxInit("images/level 1.png");
    ply->playerInit("images/CarSpriteSheet.png");
    bitcoinTex->loadTexture("images/coin.png");
    lightcoinTex->loadTexture("images/Ecoin.png");
    spikeTex->loadTexture("images/spike.png");
    //ETex->loadTexture("images/enemy.png");

    for(int z = 0; z < 6; z++){
        lightcoin[z].xSize = lightcoin[z].ySize = 0.1;
        lightcoin[z].placeCoins(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);
        lightcoin[z].coinInit();
    }

    for(int i = 0; i < 4; i++){
        spikeball[i].xSize = spikeball[i].ySize = 0.1;
        spikeball[i].placeCoins(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);
        spikeball[i].coinInit();
    }


    for(int j = 0; j < 10; j++){
        bitcoin[j].xSize = bitcoin[j].ySize = 0.1;//(rand()% 5)/10.0;
//cout << Obj[j].xSize << " " << Obj[j].ySize << endl;
    bitcoin[j].placeCoins(((rand()% 20)-10)/10.0,(rand()% 10)/10.0, -0.5);//((rand()% 10)-10)/10.0,-0.5);

    //Obj[i].ySize = (rand()% 10)/10.0;
    bitcoin[j].coinInit();

    }


    return true;
}

GLint LevelOne::drawGLScene()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
glLoadIdentity();

///////////////////////////////////////////////////////
glPushMatrix();
plx->drawSquare(screenWidth,screenHeight);
glPopMatrix();
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

glPushMatrix();

    bitcoinTex->binder();

    for(int i =0; i < 10; i++){

       bitcoin[i].drawCoin();


    }
glPopMatrix();

///////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

glPushMatrix();
lightcoinTex->binder();
for(int z =0; z < 6; z++){

       lightcoin[z].drawCoin();


    }
glPopMatrix();

glPushMatrix();
spikeTex->binder();
for(int j = 0; j < 4; j++){

    spikeball[j].drawCoin(0);
}

glPopMatrix();

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
glPushMatrix();

glPopMatrix();
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
glPushMatrix();
    glTranslated(ply->xPos,ply->yPos,ply->zPos);
    glScaled(0.15,0.15,0.15);
    ply->drawPlayer();
    ply->playerActions();
glPopMatrix();
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////

}

int LevelOne::winMsg(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(wParam){
case VK_LEFT:
    ply->actionTrigger = "Left";
    break;
case VK_RIGHT:
    ply->actionTrigger = "Right";
    break;
case VK_UP:
    ply->actionTrigger = "Up";
    break;
case VK_DOWN:
    ply->actionTrigger = "Down";
    break;
}


   switch(uMsg){
        case WM_KEYDOWN:

            KbMs ->wParam = wParam;
			//KbMs ->keyPressed(Mdl);
			KbMs ->keyEnv(plx,0.005);
			KbMs ->playerAction(ply);
            if(wParam == int('p') || wParam == int('P')){
                // go to first level.
                /*
                if(mouseX > -4.9767 && mouseX < 0.668879 && mouseY > 0.68 && mouseY < 1.4114){
                    GLScene* scene = new GLScene();
                    loader->loadScene("level1", scene);
                }
                */
            }
            //ply ->actionTrigger = "Down";
	    break;

        case WM_KEYUP:								// Has A Key Been Released?
		{
			//ply ->actionTrigger = "Up";								// Jump Back


		}break;



		case WM_LBUTTONDOWN:
        {
            //ply ->actionTrigger = "Left";
            //KbMs->wParam = wParam;
            //KbMs->mouseEventDown(Mdl, LOWORD(lParam),HIWORD(lParam));
            GLdouble modelMat[16];
            GLdouble projMat[16];
            GLint viewport[4];
            glGetDoublev(GL_MODELVIEW_MATRIX, modelMat);
            glGetDoublev(GL_PROJECTION_MATRIX, projMat);
            glGetIntegerv(GL_VIEWPORT, viewport);
            //cout << LOWORD(lParam) << ", " << HIWORD(lParam) << endl;
            GLScene::convertMouseCoord((float)LOWORD(lParam), (float) viewport[3] - (GLfloat)HIWORD(lParam) - 1, modelMat, projMat, viewport);
            if(mouseX > -4.9767 && mouseX < 0.668879 && mouseY > 0.68 && mouseY < 1.4114){
                //GLScene* scene = new GLScene();
                //loader->loadScene("level1", scene);
            }
            else if(mouseX > -4.96443 && mouseX < -1.96982 && mouseY < -0.902066 && mouseY > -1.68754){
                DestroyWindow(hWnd);
            }

        break;								// Jump Back
        }
    }
}

